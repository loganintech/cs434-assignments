Hello. This assignment was developed by Rajat Kulkarni, Evan Medinger, and
Logan Saso. To run the code, enter the local directory for 'as4' in the
terminal and call the command 'py ./src/main.py' to run the default
settings of the program. To edit the settings, the lines 21, 23, and 26-28
inside of "main.py" affect the output of the program. The following gives
further explanation to each of the specific lines:

21: This enables PCA with a 1 or disabled 0. Default is 1.

23: This enables kmeans with a 1 or disabled 0. Default is 1.

26: Changing this value affects PCA retain ratio that is used. Default .9

27: This affects the number of k centers that are used. Default 15

28: This affects the maximum iterations kmeans loops through. Default 20